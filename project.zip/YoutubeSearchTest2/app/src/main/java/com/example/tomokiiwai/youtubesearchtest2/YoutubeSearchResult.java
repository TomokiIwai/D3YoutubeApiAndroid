package com.example.tomokiiwai.youtubesearchtest2;

import java.util.List;

/**
 * Youtube検索APIのレスポンスデータ
 */
public class YoutubeSearchResult {
    public List<Item> items;

    /**
     * Youtubeデータ
     */
    public static class Item {
        Id id;
        Snippet snippet;

        /**
         * このオブジェクトの文字列表現を取得します。
         * 標準的なListViewで表示される文字列はここで制御します。
         *
         *
         */
        @Override
        public String toString() {
            return snippet.title;
        }
    }

    /**
     * Youtubeデータ識別子
     */
    public static class Id {
        public String videoId;
    }

    /**
     * Youtubeデータ詳細
     */
    public static class Snippet {
        public Thumbnail thumbnails;
        public String title;
    }

    /**
     * Youtubeデータサムネイル
     */
    public static class Thumbnail {
        public Url medium;
        public Url high;
    }

    /**
     * YoutubeデータURL
     */
    public static class Url {
        public String url;
    }
}
