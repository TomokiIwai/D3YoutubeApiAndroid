package com.example.tomokiiwai.youtubesearchtest2;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import de.greenrobot.event.EventBus;
import retrofit.RestAdapter;


/**
 * YouTube検索画面フラグメント
 */
public class MainActivityFragment extends Fragment {
    // Google APIのエンドポイント
    private static final String GOOGLE_END_POINT = "https://www.googleapis.com";

    //
    // View(画面を構成する部品)
    //
    // 検索文字を入力する部分
    @BindView(R.id.edit_text)
    EditText mEditText;
    // サムネイル画像を表示する部分
    @BindView(R.id.list_view)
    RecyclerView mListView;
    // 再生中に表示する半透明の部分
    @BindView(R.id.web_view_container)
    View mVideoContainer;
    // YouTubeを再生する部分
    @BindView(R.id.web_view)
    WebView mVideoPlayer;

    // YouTube APIにアクセスするためのクライアント
    private YoutubeApi mYoutubeApi;
    // YouTubeのデータと画面部品を関連付けるためのアダプター
    private Adapter mAdapter;
    // ButterKnifeのUnBinder
    private Unbinder mUnbinder;

    /**
     * コンストラクタ
     */
    public MainActivityFragment() {
        mYoutubeApi = new RestAdapter.Builder()
                .setEndpoint(GOOGLE_END_POINT)
                .build()
                .create(YoutubeApi.class);
    }

    /**
     * ユーザーインターフェース生成時に呼び出されます。
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // XMLから画面を生成
        View view = inflater.inflate(R.layout.fragment_main, container, false);

        // 画面上の部品を探す
        mUnbinder = ButterKnife.bind(this, view);

        // 画面部品の初期設定を行う
        initializeView();

        return view;
    }

    /**
     * UIの初期化処理を行います。
     */
    private void initializeView() {
        // アダプタを生成
        mAdapter = new Adapter(getActivity());
        // アダプタを設定
        mListView.setAdapter(mAdapter);

        // WebViewを初期化
        mVideoPlayer.getSettings().setJavaScriptEnabled(true);
        // ページロードをWebView内でハンドリング
        mVideoPlayer.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return false;
            }
        });
    }

    /**
     * UIが表示される段階で呼び出されます。
     */
    @Override
    public void onStart() {
        super.onStart();

        // このクラス(this)で、EventBusを利用開始する
        EventBus.getDefault().register(this);
    }

    /**
     * UIが非表示になる段階で呼び出されます。
     */
    @Override
    public void onStop() {
        // このクラス(this)で、EventBusの利用を終了する
        EventBus.getDefault().unregister(this);

        super.onStop();
    }

    /**
     * UIが破棄される際に呼び出されます。
     */
    @Override
    public void onDestroyView() {
        mUnbinder.unbind();
        super.onDestroyView();
    }

    /**
     * 検索ボタンがクリックされた際に呼び出されます。
     */
    @SuppressWarnings("unused")
    @OnClick(R.id.button)
    public void onClickButton() {
        hideIme();

        // TODO 検索ボタンが押された時に呼び出されることを確認する
//        Toast.makeText(getActivity(), "きたよ!", Toast.LENGTH_LONG).show();

        // TODO YouTube 検索 APIを呼び出す
//        Editable text = mEditText.getText();
//        if (!TextUtils.isEmpty(text)) {
//            mYoutubeApi.search(text.toString(), new YoutubeSearchCallback());
//        }
    }

    /**
     * Youtube検索が完了した際に呼び出されます。
     *
     * @param event イベントオブジェクト
     */
    @SuppressWarnings("unused")
    public void onEventMainThread(YoutubeApi.SearchCompletedEvent event) {
        mAdapter.clear();
        mAdapter.addAll(event.result.items);
    }

    /**
     * ViewViewがクリックされた際に呼び出されます。
     *
     * @param event イベントオブジェクト
     */
    @SuppressWarnings("unused")
    public void onEventMainThread(VideoViewHolder.VideoViewClickEvent event) {
        mVideoContainer.setVisibility(View.VISIBLE);
        mVideoPlayer.loadUrl("http://m.youtube.com/watch?v=" + event.videoId);
    }

    /**
     * Videoコンテナをクリックした際に呼び出されます。
     */
    @SuppressWarnings("unused")
    @OnClick(R.id.web_view_container)
    public void onClickVideoContainer() {
        mVideoContainer.setVisibility(View.GONE);
        mVideoPlayer.loadData("", "text/plain", "utf-8");
    }

    /**
     * IMEを閉じます。
     */
    private void hideIme() {
        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(mEditText.getWindowToken(), 0);
    }

    /**
     * ビデオ情報を表示するViewHolderクラス
     */
    public static class VideoViewHolder extends RecyclerView.ViewHolder {
        // TODO YouTubeから取得したサムネイル画像を表示する
//        @BindView(R.id.image_view)
//        ImageView img;
        @BindView(R.id.text_view)
        TextView textview;

        private YoutubeSearchResult.Item mItem;

        /**
         * コンストラクタ
         */
        public VideoViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }

        /**
         * YouTube API結果データを設定します。
         *
         * @param item {@link com.example.tomokiiwai.youtubesearchtest2.YoutubeSearchResult.Item}
         */
        public void setValue(YoutubeSearchResult.Item item, int position) {
            mItem = item;

            // タイトルを設定
            textview.setText(item.snippet.title);

            // TODO YouTubeから取得したサムネイル画像を表示する
//            // YouTube APIの結果から、サムネイル画像のURLを取得
//            String url = item.snippet.thumbnails.high.url;
//
//            // 幅300 高さは、positionが偶数なら200、奇数なら400
//            int w = 300;
//            int h = (position % 2 + 1) * 200;
//
//            //
//            // Picassoに、画像のダウンロードと表示を任せる
//            // ついでに、リサイズしてもらったり
//            // 大きい画像は真ん中を切り取ってもらったりする
//            //
//            // 余裕があればcenterCrop()とcenterInside()の違いを検証してみましょう
//            // さらに、placeholder(R.drawable.hour_glass)としてロード中の画像を指定してみましょう
//            //
//            Picasso.with(img.getContext())
//                    .load(url)
//                    .resize(w, h)
//                    .centerCrop()
//                    .placeholder(R.drawable.hour_glass)
//                    .into(img);
        }

        /**
         * VideoViewがクリックされた際に呼び出されます。
         */
        @OnClick(R.id.cell)
        public void onClick() {
            EventBus.getDefault().post(new VideoViewClickEvent(mItem.id.videoId));
        }

        /**
         * VideoViewクリックイベントクラス
         */
        public static class VideoViewClickEvent {
            public String videoId;

            /**
             * コンストラクタ
             *
             * @param id YouTube Video ID
             */
            public VideoViewClickEvent(String id) {
                videoId = id;
            }
        }
    }

    /**
     * GridViewとデータを紐付けるアダプタクラス
     */
    private static class Adapter extends RecyclerView.Adapter<VideoViewHolder> {
        // LayoutInflater
        private LayoutInflater mInflater;
        // データ
        private List<YoutubeSearchResult.Item> mData = new ArrayList<>();

        /**
         * コンストラクタ
         */
        public Adapter(Context context) {
            mInflater = LayoutInflater.from(context);
        }

        /**
         * VideoViewHolderを生成します。
         */
        @Override
        public VideoViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            return new VideoViewHolder(mInflater.inflate(R.layout.cell, parent, false));
        }

        /**
         * VideoViewHolderにYouTube API結果データを設定します。
         */
        @Override
        public void onBindViewHolder(VideoViewHolder holder, int position) {
            holder.setValue(mData.get(position), position);
        }

        /**
         * データ数を取得します。
         */
        @Override
        public int getItemCount() {
            return mData.size();
        }

        /**
         * データを追加します。
         */
        public void addAll(Collection<YoutubeSearchResult.Item> list) {
            final int prevCount = mData.size();
            mData.addAll(list);
            notifyItemRangeInserted(prevCount, list.size());
        }

        /**
         * データをクリアします。
         */
        public void clear() {
            mData.clear();
            notifyDataSetChanged();
        }
    }
}
