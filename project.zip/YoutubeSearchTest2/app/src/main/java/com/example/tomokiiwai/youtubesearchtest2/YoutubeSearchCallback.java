package com.example.tomokiiwai.youtubesearchtest2;

import android.util.Log;

import de.greenrobot.event.EventBus;
import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * Youtube検索APIの呼び出し結果ハンドラー
 */
public class YoutubeSearchCallback implements Callback<YoutubeSearchResult> {
    /**
     * Successful HTTP response.
     *
     * @param youtubeSearchResult Youtube検索APIのレスポンスデータ
     * @param response            HTTP response
     */
    @Override
    public void success(YoutubeSearchResult youtubeSearchResult, Response response) {
        // 検索完了イベントを生成
        YoutubeApi.SearchCompletedEvent event = new YoutubeApi.SearchCompletedEvent();
        event.result = youtubeSearchResult;

        // 通知
        EventBus.getDefault().post(event);
    }

    /**
     * Unsuccessful HTTP response due to network failure, non-2XX status code, or unexpected
     * exception.
     *
     * @param error RuntimeException
     */
    @Override
    public void failure(RetrofitError error) {
        Log.e("YOUTUBE", error.getMessage());
    }
}
