package com.example.tomokiiwai.youtubesearchtest2;

import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;

/**
 * YoutubeAPIクライアント
 */
public interface YoutubeApi {
    /**
     * 検索APIを呼び出します。
     *
     * @param q 検索ワード
     */
    @GET("/youtube/v3/search?type=video&part=snippet&order=viewCount&maxResults=50&safeSearch=strict")
    void search(@Query("q") String q, Callback<YoutubeSearchResult> cb);

    /**
     * 検索完了イベントクラス
     */
    class SearchCompletedEvent {
        public YoutubeSearchResult result;
    }
}
