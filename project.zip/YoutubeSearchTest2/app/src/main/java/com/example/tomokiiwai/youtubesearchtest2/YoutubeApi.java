package com.example.tomokiiwai.youtubesearchtest2;

import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;

/**
 * YoutubeAPIクライアント
 */
public interface YoutubeApi {
    /**
     * 検索APIを呼び出します。
     *
     * 余裕があれば、YouTube APIのリファレンスを参照して、各パラメータの値を変更したり
     * 新たなパラメータを追加してみましょう。
     *
     * YouTube APIリファレンス
     * https://developers.google.com/youtube/v3/docs/search/list?hl=ja
     *
     * さらに、画面から変更してみたいパラメータを追加してみましょう。
     *
     * @param q 検索ワード
     */
    @GET("/youtube/v3/search?type=video&part=snippet&order=viewCount&maxResults=50&safeSearch=strict")
    void search(@Query("q") String q, Callback<YoutubeSearchResult> cb);

    /**
     * 検索完了イベントクラス
     */
    class SearchCompletedEvent {
        public YoutubeSearchResult result;
    }
}
